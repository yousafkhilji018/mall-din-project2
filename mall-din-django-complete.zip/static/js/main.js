/* ============================================
   MALL DIN Cash & Carry - Main JavaScript
   ============================================ */

document.addEventListener('DOMContentLoaded', function () {
    initMobileMenu();
    initStickyHeader();
    initCartFunctions();
    initSearch();
    initNewsletter();
    initContactForm();
    initFormValidation();
    initSmoothScroll();
    initQuantityButtons();
    initImageGallery();
    initAlertDismiss();
    initBackToTop();
    initProductTabs();
    initWishlistButtons();
    initPaymentMethods();
    initScrollReveal();
    initQuickView();
});

/* ============================================
   Mobile Menu Toggle
   ============================================ */
function initMobileMenu() {
    var hamburger = document.getElementById('hamburgerBtn');
    var nav = document.getElementById('headerNav');

    if (!hamburger || !nav) return;

    hamburger.addEventListener('click', function () {
        this.classList.toggle('active');
        nav.classList.toggle('nav-open');
        document.body.style.overflow = nav.classList.contains('nav-open') ? 'hidden' : '';
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            hamburger.classList.remove('active');
            nav.classList.remove('nav-open');
            document.body.style.overflow = '';
        }
    });
}

/* ============================================
   Sticky Header Shadow
   ============================================ */
function initStickyHeader() {
    var header = document.getElementById('siteHeader');
    if (!header) return;

    window.addEventListener('scroll', function () {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
}

/* ============================================
   Cart Functions
   ============================================ */
function initCartFunctions() {
    document.querySelectorAll('.add-to-cart-btn, .product-card-add-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            var form = this.closest('form');
            if (!form) return;

            e.preventDefault();
            var submitBtn = this;
            var originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';

            fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (data.success) {
                    showToast(data.message || 'Added to Cart âœ“', 'success');
                    updateCartBadge(data.cart_count);
                    submitBtn.innerHTML = '<i class="fas fa-check"></i> Added';
                    submitBtn.classList.add('added');
                    setTimeout(function () {
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                        submitBtn.classList.remove('added');
                    }, 2000);
                } else {
                    showToast(data.message || 'Failed to add item', 'error');
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }
            })
            .catch(function (error) {
                console.error('Cart error:', error);
                form.submit();
            });
        });
    });
}

function updateCartBadge(count) {
    var badges = document.querySelectorAll('.cart-badge');
    badges.forEach(function (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    });
}

/* ============================================
   Toast Notifications
   ============================================ */
function showToast(message, type) {
    type = type || 'info';
    var container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    var icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };

    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.innerHTML = '<span class="toast-icon"><i class="fas ' + (icons[type] || icons.info) + '"></i></span>' +
        '<span class="toast-message">' + message + '</span>' +
        '<button class="toast-close" onclick="this.parentElement.remove()">&times;</button>';

    container.appendChild(toast);

    setTimeout(function () {
        toast.classList.add('toast-hide');
        setTimeout(function () {
            if (toast.parentNode) toast.remove();
        }, 300);
    }, 4000);
}

/* ============================================
   Search Functionality
   ============================================ */
function initSearch() {
    var searchForms = document.querySelectorAll('.header-search form, .store-search');
    searchForms.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var input = this.querySelector('input[name="q"]');
            if (input && !input.value.trim()) {
                e.preventDefault();
                showToast('Please enter a search term.', 'warning');
                input.focus();
            }
        });
    });
}

/* ============================================
   Newsletter Form Handling
   ============================================ */
function initNewsletter() {
    var forms = document.querySelectorAll('.newsletter-form');
    forms.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var emailInput = this.querySelector('input[type="email"]');
            var submitBtn = this.querySelector('button');

            if (!emailInput || !emailInput.value.trim()) {
                showToast('Please enter your email address.', 'error');
                return;
            }

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Subscribing...';

            fetch(form.action, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(function (response) {
                return response.text().then(function () {
                    showToast('Thank you for subscribing!', 'success');
                    emailInput.value = '';
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Subscribe';
                });
            })
            .catch(function (error) {
                showToast('An error occurred. Please try again.', 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Subscribe';
            });
        });
    });
}

/* ============================================
   Contact Form Handling
   ============================================ */
function initContactForm() {
    var contactForm = document.querySelector('#contact-form');
    if (!contactForm) return;

    contactForm.addEventListener('submit', function (e) {
        var requiredFields = this.querySelectorAll('[required]');
        var isValid = true;

        requiredFields.forEach(function (field) {
            clearFieldError(field);
            if (!field.value.trim()) {
                showFieldError(field, 'This field is required.');
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
            showToast('Please fill in all required fields.', 'error');
        }
    });
}

/* ============================================
   Form Validation
   ============================================ */
function initFormValidation() {
    var forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var isValid = true;
            var requiredFields = form.querySelectorAll('[required]');

            requiredFields.forEach(function (field) {
                clearFieldError(field);
                if (!field.value.trim()) {
                    showFieldError(field, 'This field is required.');
                    isValid = false;
                } else if (field.type === 'email' && !isValidEmail(field.value)) {
                    showFieldError(field, 'Please enter a valid email.');
                    isValid = false;
                }
            });

            var password = form.querySelector('#password');
            var confirmPassword = form.querySelector('#confirm-password');
            if (password && confirmPassword && password.value && confirmPassword.value) {
                if (password.value !== confirmPassword.value) {
                    showFieldError(confirmPassword, 'Passwords do not match.');
                    isValid = false;
                }
            }

            if (!isValid) {
                e.preventDefault();
            }
        });
    });
}

function showFieldError(field, message) {
    field.classList.add('field-error');
    var existingError = field.parentElement.querySelector('.field-error-msg');
    if (existingError) existingError.remove();
    var errorDiv = document.createElement('div');
    errorDiv.className = 'field-error-msg';
    errorDiv.textContent = message;
    errorDiv.style.color = '#dc3545';
    errorDiv.style.fontSize = '0.75rem';
    errorDiv.style.marginTop = '0.25rem';
    field.parentElement.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.classList.remove('field-error');
    var existingError = field.parentElement.querySelector('.field-error-msg');
    if (existingError) existingError.remove();
}

/* ============================================
   Smooth Scrolling
   ============================================ */
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
        anchor.addEventListener('click', function (e) {
            var targetId = this.getAttribute('href');
            if (targetId === '#') return;
            var target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                var headerHeight = document.querySelector('.site-header') ? document.querySelector('.site-header').offsetHeight : 0;
                window.scrollTo({
                    top: target.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20,
                    behavior: 'smooth'
                });
            }
        });
    });
}

/* ============================================
   Product Quantity Buttons
   ============================================ */
function initQuantityButtons() {
    document.querySelectorAll('.quantity-control').forEach(function (selector) {
        var minusBtn = selector.querySelector('.qty-btn.minus, .quantity-btn:first-child');
        var plusBtn = selector.querySelector('.qty-btn.plus, .quantity-btn:last-child');
        var input = selector.querySelector('input');

        if (!minusBtn || !plusBtn || !input) return;

        minusBtn.addEventListener('click', function () {
            var val = parseInt(input.value) || 1;
            if (val > 1) {
                input.value = val - 1;
                input.dispatchEvent(new Event('change'));
            }
        });

        plusBtn.addEventListener('click', function () {
            var val = parseInt(input.value) || 1;
            var max = parseInt(input.getAttribute('max')) || 99;
            if (val < max) {
                input.value = val + 1;
                input.dispatchEvent(new Event('change'));
            }
        });

        input.addEventListener('input', function () {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    });
}

/* ============================================
   Image Gallery on Product Detail
   ============================================ */
function initImageGallery() {
    var mainImage = document.querySelector('.product-main-image img');
    var thumbnails = document.querySelectorAll('.product-thumbnail, .product-thumb');

    if (!mainImage || thumbnails.length === 0) return;

    thumbnails.forEach(function (thumb) {
        thumb.addEventListener('click', function () {
            var imgSrc = this.querySelector('img') ? this.querySelector('img').src : this.getAttribute('data-src');
            if (imgSrc) {
                mainImage.style.opacity = '0';
                setTimeout(function () {
                    mainImage.src = imgSrc;
                    mainImage.style.opacity = '1';
                }, 200);
            }
            thumbnails.forEach(function (t) { t.classList.remove('active'); });
            this.classList.add('active');
        });
    });

    mainImage.style.transition = 'opacity 0.2s ease';
}

/* ============================================
   Alert Auto-Dismiss
   ============================================ */
function initAlertDismiss() {
    document.querySelectorAll('.alert .alert-close').forEach(function (btn) {
        btn.addEventListener('click', function () {
            dismissAlert(this.closest('.alert'));
        });
    });

    setTimeout(function () {
        document.querySelectorAll('.alert').forEach(function (alert) {
            dismissAlert(alert);
        });
    }, 6000);
}

function dismissAlert(alertEl) {
    if (!alertEl) return;
    alertEl.style.transition = 'all 0.3s';
    alertEl.style.opacity = '0';
    alertEl.style.transform = 'translateX(100px)';
    setTimeout(function () {
        if (alertEl.parentNode) alertEl.remove();
    }, 300);
}

/* ============================================
   Back to Top Button
   ============================================ */
function initBackToTop() {
    var btn = document.getElementById('backToTop');
    if (!btn) return;

    window.addEventListener('scroll', function () {
        if (window.scrollY > 400) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    });

    btn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

/* ============================================
   Product Tabs
   ============================================ */
function initProductTabs() {
    var tabHeaders = document.querySelectorAll('.tab-btn');
    var tabPanes = document.querySelectorAll('.tab-content');

    if (tabHeaders.length === 0) return;

    tabHeaders.forEach(function (header) {
        header.addEventListener('click', function () {
            var targetTab = this.dataset.tab;
            tabHeaders.forEach(function (h) { h.classList.remove('active'); });
            this.classList.add('active');
            tabPanes.forEach(function (pane) {
                pane.classList.remove('active');
                if (pane.dataset.tab === targetTab) {
                    pane.classList.add('active');
                }
            });
        });
    });
}

/* ============================================
   Wishlist Buttons
   ============================================ */
function initWishlistButtons() {
    document.querySelectorAll('.wishlist-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            this.classList.toggle('active');
            var icon = this.querySelector('i');
            if (icon) {
                if (this.classList.contains('active')) {
                    icon.classList.remove('far');
                    icon.classList.add('fas');
                    showToast('Added to wishlist!', 'success');
                } else {
                    icon.classList.remove('fas');
                    icon.classList.add('far');
                    showToast('Removed from wishlist.', 'info');
                }
            }
        });
    });
}

/* ============================================
   Payment Methods Toggle
   ============================================ */
function initPaymentMethods() {
    var methods = document.querySelectorAll('.payment-method-card');
    methods.forEach(function (method) {
        var radio = method.querySelector('input[type="radio"]');
        if (radio) {
            method.addEventListener('click', function () {
                methods.forEach(function (m) { m.classList.remove('active'); });
                this.classList.add('active');
                radio.checked = true;
            });
            if (radio.checked) method.classList.add('active');
        }
    });
}

/* ============================================
   Scroll Reveal Animation
   ============================================ */
function initScrollReveal() {
    var elements = document.querySelectorAll('.reveal');
    if (elements.length === 0) return;

    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    elements.forEach(function (el) { observer.observe(el); });
}

/* ============================================
   Quick View Modal
   ============================================ */
function initQuickView() {
    document.querySelectorAll('.quick-view-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var modal = document.getElementById('quickViewModal');
            if (modal) {
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        });
    });

    var closeBtn = document.querySelector('.modal-close');
    var modalOverlay = document.querySelector('.modal-overlay');
    if (closeBtn) {
        closeBtn.addEventListener('click', closeModal);
    }
    if (modalOverlay) {
        modalOverlay.addEventListener('click', closeModal);
    }

    function closeModal() {
        var modal = document.querySelector('.modal');
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }
}

/* ============================================
   Utility Functions
   ============================================ */
function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getCsrfToken() {
    var cookie = document.cookie.split(';').find(function (c) {
        return c.trim().startsWith('csrftoken=');
    });
    if (cookie) return cookie.split('=')[1];
    var meta = document.querySelector('meta[name="csrf-token"]');
    if (meta) return meta.getAttribute('content');
    var input = document.querySelector('input[name="csrfmiddlewaretoken"]');
    if (input) return input.value;
    return '';
}
