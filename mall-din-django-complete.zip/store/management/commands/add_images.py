from django.core.management.base import BaseCommand
from store.models import Category, Product


class Command(BaseCommand):
    help = 'Add image URLs to all categories and products'

    def handle(self, *args, **options):
        self.stdout.write('Adding images to categories and products...')
        self.add_category_images()
        self.add_product_images()
        self.stdout.write(self.style.SUCCESS('Images added successfully!'))

    def add_category_images(self):
        category_images = {
            'Grocery': 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&h=400&fit=crop',
            'Household': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600&h=400&fit=crop',
            'Personal Care': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Home & Kitchen': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Rice & Grains': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600&h=400&fit=crop',
            'Sugar & Salt': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=600&h=400&fit=crop',
            'Flour & Atta': 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&h=400&fit=crop',
            'Cooking Oil & Ghee': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&h=400&fit=crop',
            'Pulses & Daal': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=600&h=400&fit=crop',
            'Spices & Masala': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=600&h=400&fit=crop',
            'Tea & Coffee': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=600&h=400&fit=crop',
            'Dairy & Eggs': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=600&h=400&fit=crop',
            'Bakery & Bread': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&h=400&fit=crop',
            'Biscuits & Cookies': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&h=400&fit=crop',
            'Cereals & Noodles': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=600&h=400&fit=crop',
            'Sauces & Pickles': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=600&h=400&fit=crop',
            'Dry Fruits & Nuts': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=600&h=400&fit=crop',
            'Snacks & Chocolates': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=600&h=400&fit=crop',
            'Juices & Drinks': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=600&h=400&fit=crop',
            'Water': 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=600&h=400&fit=crop',
            'Laundry': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=600&h=400&fit=crop',
            'Dishwashing': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Cleaners': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600&h=400&fit=crop',
            'Tissues & Bags': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=600&h=400&fit=crop',
            'Kitchen Wrap': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Cleaning Tools': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600&h=400&fit=crop',
            'Buckets & Dustbins': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600&h=400&fit=crop',
            'Air Fresheners': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Insect Killers': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600&h=400&fit=crop',
            'Hair Care': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Bath & Body': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Oral Care': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Deodorants': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Shaving': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Skincare': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Baby Care': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=600&h=400&fit=crop',
            'Dinnerware': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Drinkware': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Cutlery': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Cooking Utensils': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Storage': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Bottles': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Kitchen Accessories': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
            'Household Accessories': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop',
        }

        updated = 0
        for cat_name, image_url in category_images.items():
            cat = Category.objects.filter(name=cat_name).first()
            if cat and not cat.image_url:
                cat.image_url = image_url
                cat.save()
                updated += 1
        self.stdout.write(f'  Updated {updated} categories with images')

    def add_product_images(self):
        product_images = {
            # Rice & Grains
            'basmati-rice-national-5kg': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop',
            'super-basmati-rice-shaad-5kg': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop',
            'broken-basmati-rice-generic-5kg': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop',
            'chakki-fresh-atta-national-10kg': 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=400&h=400&fit=crop',
            'white-rice-generic-5kg': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop',
            'sella-basmati-rice-falak-5kg': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop',
            # Sugar & Salt
            'sugar-generic-1kg': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=400&h=400&fit=crop',
            'sugar-generic-5kg': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=400&h=400&fit=crop',
            'fine-salt-national-800g': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=400&h=400&fit=crop',
            'pink-himalayan-salt-shan-1kg': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=400&h=400&fit=crop',
            'black-salt-national-500g': 'https://images.unsplash.com/photo-1587137350369-e31b7c12e637?w=400&h=400&fit=crop',
            # Cooking Oil & Ghee
            'cooking-oil-sufi-1l': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            'cooking-oil-sufi-5l': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            'cooking-oil-dalda-1l': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            'ghee-national-1kg': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            'banaspati-ghee-dalda-1kg': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            'olive-oil-mehran-500ml': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&h=400&fit=crop',
            # Pulses & Daal
            'moong-daal-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            'masoor-daal-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            'chana-daal-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            'white-chickpeas-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            'black-gram-daal-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            'red-kidney-beans-generic-1kg': 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400&h=400&fit=crop',
            # Spices & Masala
            'black-tea-vital-950g': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=400&fit=crop',
            'green-tea-vital-100-bags': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=400&fit=crop',
            'red-chilli-powder-shan-500g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            'turmeric-powder-national-250g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            'coriander-powder-shan-250g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            'garam-masala-national-100g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            'cumin-seeds-shan-200g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            'biryani-masala-shan-50g': 'https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=400&h=400&fit=crop',
            # Tea & Coffee
            'tea-leaves-lipton-500g': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=400&fit=crop',
            'coffee-nescafe-200g': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=400&fit=crop',
            'coffee-nescafe-100g': 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=400&fit=crop',
            # Dairy & Eggs
            'milk-olper-s-1l': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'milk-milkpak-1l': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'milk-powder-Everyday-1-5kg': 'https://pictures.grocerapps.com/original/grocerapp-nestle-everyday-original-powder-tea-6597d15d30786.png',
            'yogurt-olper-s-500g': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'butter-blue-band-250g': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'cheese-adam-s-400g': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'eggs-generic-12-pack': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            'cream-olper-s-200ml': 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=400&h=400&fit=crop',
            # Bakery & Bread
            'bread-national-800g': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=400&fit=crop',
            'bread-national-400g': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=400&fit=crop',
            'whole-wheat-bread-national-600g': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=400&fit=crop',
            # Biscuits & Cookies
            'biscuits-peek-freans-300g': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=400&fit=crop',
            'cookies-lu-200g': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=400&fit=crop',
            'marie-biscuits-peek-freans-250g': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=400&fit=crop',
            'glucose-biscuits-super-350g': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=400&fit=crop',
            # Cereals & Noodles
            'corn-flakes-nestle-500g': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=400&h=400&fit=crop',
            'pasta-bake-parlor-500g': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=400&h=400&fit=crop',
            'noodles-knorr-70g': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=400&h=400&fit=crop',
            'spaghetti-bake-parlor-500g': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=400&h=400&fit=crop',
            'oats-quaker-500g': 'https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=400&h=400&fit=crop',
            # Sauces & Pickles
            'ketchup-national-800g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'soy-sauce-national-250ml': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'chilli-garlic-sauce-national-500g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'mango-pickle-national-900g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'vinegar-national-800ml': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'mayonnaise-young-s-500g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'jam-mitchell-s-500g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            'honey-marhaba-500g': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=400&fit=crop',
            # Dry Fruits & Nuts
            'almonds-generic-500g': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400&h=400&fit=crop',
            'cashews-generic-250g': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400&h=400&fit=crop',
            'raisins-generic-500g': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400&h=400&fit=crop',
            'walnuts-generic-250g': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400&h=400&fit=crop',
            'dates-generic-1kg': 'https://images.unsplash.com/photo-1599599810769-bcde5a160d32?w=400&h=400&fit=crop',
            # Snacks & Chocolates
            'chips-lays-70g': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=400&h=400&fit=crop',
            'chocolate-cadbury-120g': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=400&h=400&fit=crop',
            'wafers-prince-100g': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=400&h=400&fit=crop',
            'namkeen-haldiram-s-200g': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=400&h=400&fit=crop',
            'popcorn-act-ii-70g': 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?w=400&h=400&fit=crop',
            # Juices & Drinks
            'juice-nestle-1l': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=400&fit=crop',
            'soft-drink-coca-cola-1-5l': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=400&fit=crop',
            'soft-drink-pepsi-1-5l': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=400&fit=crop',
            'rooh-afza-hamdard-1l': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=400&fit=crop',
            'squash-mitchell-s-750ml': 'https://images.unsplash.com/photo-1622597467836-f3285f2131b8?w=400&h=400&fit=crop',
            # Water
            'mineral-water-nestle-1-5l': 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&h=400&fit=crop',
            'mineral-water-aquafina-1-5l': 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&h=400&fit=crop',
            'water-bottles-nestle-250ml-x-12': 'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&h=400&fit=crop',
            # Household - Laundry
            'washing-powder-ariel-1kg': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'washing-powder-surf-excel-1kg': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'detergent-liquid-ariel-2l': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'fabric-softener-downy-1l': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'stain-remover-vanish-500g': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            # Household - Dishwashing
            'dishwashing-liquid-morning-fresh-500ml': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'dishwashing-soap-vim-3-pack': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            'dishwasher-tablet-finish-30-tabs': 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=400&h=400&fit=crop',
            # Household - Cleaners
            'floor-cleaner-lizol-1l': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'toilet-cleaner-harpic-500ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'glass-cleaner-klear-500ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'bleach-hamam-500ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'surface-cleaner-domex-500ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            # Household - Tissues & Bags
            'tissue-box-fine-150-sheets': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            'toilet-tissue-fine-6-roll': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            'kitchen-towels-fine-2-roll': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            'garbage-bags-generic-30-bags': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            'aluminium-foil-generic-9m': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            'cling-film-generic-30m': 'https://images.unsplash.com/photo-1584556812952-905ffd026909?w=400&h=400&fit=crop',
            # Household - Cleaning Tools
            'sponges-generic-3-pack': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'scrubbers-generic-5-pack': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'broom-generic-1-pc': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'mop-generic-1-set': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            # Household - Buckets & Dustbins
            'buckets-generic-1-pc': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'dustbin-generic-1-pc': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            # Air Fresheners
            'air-freshener-odonil-1-pc': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'room-spray-glade-300ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Insect Killers
            'insect-killer-spray-mortein-600ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            'mosquito-repellent-self-30ml': 'https://images.unsplash.com/photo-1585421514738-01798e348b17?w=400&h=400&fit=crop',
            # Personal Care - Hair Care
            'shampoo-pantene-400ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'shampoo-head-shoulders-400ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'conditioner-pantene-400ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'hair-oil-sunsilk-200ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Bath & Body
            'bath-soap-dettol-3-pack': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'bath-soap-lifebuoy-3-pack': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'hand-wash-dettol-500ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'body-wash-dove-500ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'face-wash-garnier-100ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Oral Care
            'toothpaste-colgate-150g': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'toothpaste-sensodyne-100g': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'toothbrush-oral-b-1-pc': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'mouthwash-listerine-250ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Deodorants
            'deodorant-rexona-150ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'deodorant-nivea-150ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Shaving
            'shaving-cream-gillette-100g': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'razor-blades-gillette-8-pack': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Skincare
            'moisturizer-nivea-200ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'sunscreen-nivea-100ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'petroleum-jelly-vaseline-200ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Personal Care - Baby Care
            'baby-diapers-pampers-s-3-pack': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'baby-soap-johnson-s-3-pack': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'baby-shampoo-johnson-s-300ml': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            'baby-powder-johnson-s-500g': 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop',
            # Home & Kitchen - Dinnerware
            'dinner-set-ikea-24-pieces': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'plates-ikea-4-pack': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'bowls-ikea-4-pack': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Drinkware
            'glasses-ikea-6-pack': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'cups-ikea-6-pack': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'mugs-ikea-4-pack': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Cutlery
            'cutlery-set-ikea-24-pieces': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'knife-set-ikea-5-pieces': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Cooking Utensils
            'cookware-set-ikea-5-pieces': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'frying-pan-ikea-1-pc': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'pressure-cooker-prestige-5l': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Storage
            'storage-containers-ikea-10-pieces': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'lunch-box-generic-3-compartments': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Bottles
            'water-bottle-ikea-1l': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'flask-generic-1l': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            # Home & Kitchen - Accessories
            'chopping-board-ikea-1-pc': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'rolling-pin-generic-1-pc': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'sieve-generic-1-pc': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
            'kitchen-timer-generic-1-pc': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop',
        }

        updated = 0
        for slug, image_url in product_images.items():
            product = Product.objects.filter(slug=slug).first()
            if product and not product.image_url:
                product.image_url = image_url
                product.save()
                updated += 1
        self.stdout.write(f'  Updated {updated} products with images')
