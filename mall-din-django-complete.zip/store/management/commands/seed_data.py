from django.core.management.base import BaseCommand
from django.utils.text import slugify
from store.models import Category, Product


class Command(BaseCommand):
    help = 'Seed the database with MALL DIN Cash & Carry products and categories'

    def handle(self, *args, **options):
        self.stdout.write('Seeding MALL DIN Cash & Carry database...')
        self.seed_categories()
        self.seed_products()
        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))

    def seed_categories(self):
        categories = {
            'Grocery': {
                'icon': 'ðŸ›’',
                'subcategories': [
                    'Rice & Grains', 'Sugar & Salt', 'Flour & Atta', 'Cooking Oil & Ghee',
                    'Pulses & Daal', 'Spices & Masala', 'Tea & Coffee', 'Dairy & Eggs',
                    'Bakery & Bread', 'Biscuits & Cookies', 'Cereals & Noodles',
                    'Sauces & Pickles', 'Dry Fruits & Nuts', 'Canned & Frozen Foods',
                    'Snacks & Chocolates', 'Juices & Drinks', 'Water'
                ]
            },
            'Household': {
                'icon': 'ðŸ ',
                'subcategories': [
                    'Laundry', 'Dishwashing', 'Cleaners', 'Tissues & Bags',
                    'Kitchen Wrap', 'Cleaning Tools', 'Buckets & Dustbins',
                    'Air Fresheners', 'Insect Killers'
                ]
            },
            'Personal Care': {
                'icon': 'ðŸ§´',
                'subcategories': [
                    'Hair Care', 'Bath & Body', 'Oral Care', 'Deodorants',
                    'Shaving', 'Skincare', 'Baby Care'
                ]
            },
            'Home & Kitchen': {
                'icon': 'ðŸ³',
                'subcategories': [
                    'Dinnerware', 'Drinkware', 'Cutlery', 'Cooking Utensils',
                    'Storage', 'Bottles', 'Kitchen Accessories', 'Household Accessories'
                ]
            },
        }

        for cat_name, cat_data in categories.items():
            cat, _ = Category.objects.get_or_create(
                name=cat_name,
                defaults={
                    'slug': cat_name.lower().replace(' & ', '-').replace(' ', '-'),
                    'description': f'Shop {cat_name.lower()} essentials at MALL DIN Cash & Carry',
                    'icon': cat_data['icon'],
                }
            )
            for sub_name in cat_data['subcategories']:
                Category.objects.get_or_create(
                    name=sub_name,
                    defaults={
                        'slug': sub_name.lower().replace(' & ', '-').replace(' ', '-'),
                        'description': f'{sub_name} at MALL DIN Cash & Carry',
                        'parent': cat,
                    }
                )
        self.stdout.write(f'  Created {Category.objects.count()} categories')

    def seed_products(self):
        if Product.objects.exists():
            self.stdout.write('  Products already exist, skipping...')
            return

        products = [
            # ===== RICE & GRAINS =====
            {'name': 'Basmati Rice', 'brand': 'National', 'weight': '5kg', 'price': 1650, 'old_price': 1850, 'discount_percent': 11, 'category': 'Rice & Grains', 'rating': 4.7, 'stock': 150, 'is_featured': True, 'is_bestseller': True, 'description': 'Premium long grain basmati rice, perfect for biryani and pulao. Aged for superior taste and aroma.'},
            {'name': 'Super Basmati Rice', 'brand': 'Shaad', 'weight': '5kg', 'price': 1950, 'old_price': 2200, 'discount_percent': 11, 'category': 'Rice & Grains', 'rating': 4.8, 'stock': 100, 'is_featured': True, 'description': 'Extra long grain super basmati rice. Premium quality for special occasions.'},
            {'name': 'Broken Basmati Rice', 'brand': 'Generic', 'weight': '5kg', 'price': 950, 'category': 'Rice & Grains', 'rating': 4.0, 'stock': 200, 'description': 'Economy basmati rice, great for daily cooking and kheer.'},
            {'name': 'Chakki Fresh Atta', 'brand': 'National', 'weight': '10kg', 'price': 1150, 'old_price': 1300, 'discount_percent': 12, 'category': 'Rice & Grains', 'rating': 4.6, 'stock': 120, 'is_featured': True, 'is_bestseller': True, 'description': 'Freshly ground whole wheat flour for soft rotis and chapatis.'},
            {'name': 'White Rice', 'brand': 'Generic', 'weight': '5kg', 'price': 650, 'category': 'Rice & Grains', 'rating': 4.2, 'stock': 180, 'description': 'Polished white rice for everyday meals.'},
            {'name': 'Sella Basmati Rice', 'brand': 'Falak', 'weight': '5kg', 'price': 1450, 'category': 'Rice & Grains', 'rating': 4.5, 'stock': 90, 'description': 'Parboiled sella rice, ideal for biryani and zarda.'},

            # ===== SUGAR & SALT =====
            {'name': 'Sugar', 'brand': 'Generic', 'weight': '1kg', 'price': 180, 'category': 'Sugar & Salt', 'rating': 4.3, 'stock': 300, 'is_bestseller': True, 'description': 'Fine quality refined sugar for everyday use.'},
            {'name': 'Sugar', 'brand': 'Generic', 'weight': '5kg', 'price': 850, 'category': 'Sugar & Salt', 'rating': 4.3, 'stock': 200, 'description': 'Fine quality refined sugar, bulk pack.'},
            {'name': 'Fine Salt', 'brand': 'National', 'weight': '800g', 'price': 80, 'category': 'Sugar & Salt', 'rating': 4.4, 'stock': 250, 'description': 'Iodized fine table salt, essential for every kitchen.'},
            {'name': 'Pink Himalayan Salt', 'brand': 'Shan', 'weight': '1kg', 'price': 350, 'category': 'Sugar & Salt', 'rating': 4.7, 'stock': 80, 'description': 'Natural pink salt from Himalayan mines. Rich in minerals.'},
            {'name': 'Black Salt', 'brand': 'National', 'weight': '500g', 'price': 120, 'category': 'Sugar & Salt', 'rating': 4.5, 'stock': 100, 'description': 'Kala namak for chaat, raita and special dishes.'},

            # ===== COOKING OIL & GHEE =====
            {'name': 'Cooking Oil', 'brand': 'Sufi', 'weight': '1L', 'price': 580, 'category': 'Cooking Oil & Ghee', 'rating': 4.4, 'stock': 200, 'is_bestseller': True, 'description': 'Pure vegetable cooking oil for healthy meals.'},
            {'name': 'Cooking Oil', 'brand': 'Sufi', 'weight': '5L', 'price': 2750, 'old_price': 3000, 'discount_percent': 8, 'category': 'Cooking Oil & Ghee', 'rating': 4.5, 'stock': 100, 'is_featured': True, 'description': 'Economy pack cooking oil for the whole family.'},
            {'name': 'Cooking Oil', 'brand': 'Dalda', 'weight': '1L', 'price': 620, 'category': 'Cooking Oil & Ghee', 'rating': 4.6, 'stock': 150, 'description': 'Premium quality vegetable oil by Dalda.'},
            {'name': 'Ghee', 'brand': 'National', 'weight': '1kg', 'price': 650, 'old_price': 750, 'discount_percent': 13, 'category': 'Cooking Oil & Ghee', 'rating': 4.7, 'stock': 120, 'is_featured': True, 'description': 'Pure desi ghee for authentic flavor.'},
            {'name': 'Banaspati Ghee', 'brand': 'Dalda', 'weight': '1kg', 'price': 580, 'category': 'Cooking Oil & Ghee', 'rating': 4.5, 'stock': 130, 'description': 'Creamy banaspati ghee for cooking and baking.'},
            {'name': 'Olive Oil', 'brand': 'Mehran', 'weight': '500ml', 'price': 850, 'category': 'Cooking Oil & Ghee', 'rating': 4.8, 'stock': 60, 'description': 'Extra virgin olive oil for salads and light cooking.'},

            # ===== PULSES & DAAL =====
            {'name': 'Moong Daal', 'brand': 'Generic', 'weight': '1kg', 'price': 420, 'category': 'Pulses & Daal', 'rating': 4.5, 'stock': 100, 'is_bestseller': True, 'description': 'Yellow moong daal, quick cooking and protein rich.'},
            {'name': 'Masoor Daal', 'brand': 'Generic', 'weight': '1kg', 'price': 390, 'category': 'Pulses & Daal', 'rating': 4.4, 'stock': 100, 'description': 'Red masoor daal for delicious daal tadka.'},
            {'name': 'Chana Daal', 'brand': 'Generic', 'weight': '1kg', 'price': 360, 'category': 'Pulses & Daal', 'rating': 4.3, 'stock': 120, 'description': 'Split chickpeas for daal and Haleem.'},
            {'name': 'White Chickpeas', 'brand': 'Generic', 'weight': '1kg', 'price': 400, 'category': 'Pulses & Daal', 'rating': 4.4, 'stock': 90, 'description': 'Kabuli chana for chana masala and chaat.'},
            {'name': 'Black Gram Daal', 'brand': 'Generic', 'weight': '1kg', 'price': 380, 'category': 'Pulses & Daal', 'rating': 4.3, 'stock': 80, 'description': 'Whole black gram for dal makhani.'},
            {'name': 'Red Kidney Beans', 'brand': 'Generic', 'weight': '1kg', 'price': 450, 'category': 'Pulses & Daal', 'rating': 4.5, 'stock': 70, 'description': 'Rajma for authentic rajma chawal.'},

            # ===== SPICES & MASALA =====
            {'name': 'Black Tea', 'brand': 'Vital', 'weight': '950g', 'price': 1650, 'old_price': 1850, 'discount_percent': 11, 'category': 'Spices & Masala', 'rating': 4.6, 'stock': 80, 'is_featured': True, 'is_bestseller': True, 'description': 'Premium CTC black tea leaves for strong chai.'},
            {'name': 'Green Tea', 'brand': 'Vital', 'weight': '100 bags', 'price': 450, 'category': 'Spices & Masala', 'rating': 4.5, 'stock': 60, 'description': 'Natural green tea bags for a healthy lifestyle.'},
            {'name': 'Red Chilli Powder', 'brand': 'Shan', 'weight': '500g', 'price': 280, 'category': 'Spices & Masala', 'rating': 4.7, 'stock': 100, 'description': 'Pure red chilli powder for spicy dishes.'},
            {'name': 'Turmeric Powder', 'brand': 'National', 'weight': '250g', 'price': 150, 'category': 'Spices & Masala', 'rating': 4.6, 'stock': 90, 'description': 'Haldi powder for cooking and health benefits.'},
            {'name': 'Coriander Powder', 'brand': 'Shan', 'weight': '250g', 'price': 130, 'category': 'Spices & Masala', 'rating': 4.5, 'stock': 85, 'description': 'Dhaniya powder for curries and marinades.'},
            {'name': 'Garam Masala', 'brand': 'National', 'weight': '100g', 'price': 180, 'category': 'Spices & Masala', 'rating': 4.8, 'stock': 70, 'description': 'Blend of aromatic spices for authentic Pakistani flavor.'},
            {'name': 'Cumin Seeds', 'brand': 'Shan', 'weight': '200g', 'price': 160, 'category': 'Spices & Masala', 'rating': 4.6, 'stock': 75, 'description': 'Whole jeera for tempering and seasoning.'},
            {'name': 'Biryani Masala', 'brand': 'Shan', 'weight': '50g', 'price': 85, 'category': 'Spices & Masala', 'rating': 4.9, 'stock': 150, 'is_bestseller': True, 'description': 'Ready-made biryani masala for perfect biryani every time.'},

            # ===== TEA & COFFEE =====
            {'name': 'Tea Leaves', 'brand': 'Lipton', 'weight': '500g', 'price': 650, 'category': 'Spices & Masala', 'rating': 4.5, 'stock': 90, 'description': 'Lipton yellow label tea for refreshing cups.'},
            {'name': 'Coffee', 'brand': 'Nescafe', 'weight': '200g', 'price': 750, 'category': 'Spices & Masala', 'rating': 4.7, 'stock': 60, 'is_featured': True, 'description': 'Nescafe Classic instant coffee for coffee lovers.'},
            {'name': 'Coffee', 'brand': 'Nescafe', 'weight': '100g', 'price': 420, 'category': 'Spices & Masala', 'rating': 4.6, 'stock': 80, 'description': 'Nescafe Classic small pack.'},

            # ===== DAIRY & EGGS =====
            {'name': 'Milk', 'brand': 'Olper\'s', 'weight': '1L', 'price': 330, 'category': 'Dairy & Eggs', 'rating': 4.6, 'stock': 100, 'is_bestseller': True, 'description': 'Full cream milk packed with nutrition.'},
            {'name': 'Milk', 'brand': 'Milkpak', 'weight': '1L', 'price': 280, 'category': 'Dairy & Eggs', 'rating': 4.4, 'stock': 120, 'description': 'UHT treated milk for daily use.'},
            {'name': 'Milk Powder', 'brand': 'Everyday', 'weight': '1.5kg', 'price': 1850, 'old_price': 2100, 'discount_percent': 12, 'category': 'Dairy & Eggs', 'rating': 4.8, 'stock': 50, 'is_featured': True, 'description': 'Full cream milk powder for kids and family.'},
            {'name': 'Yogurt', 'brand': 'Olper\'s', 'weight': '500g', 'price': 180, 'category': 'Dairy & Eggs', 'rating': 4.5, 'stock': 80, 'description': 'Fresh and creamy yogurt.'},
            {'name': 'Butter', 'brand': 'Blue Band', 'weight': '250g', 'price': 350, 'category': 'Dairy & Eggs', 'rating': 4.4, 'stock': 60, 'description': 'Premium margarine for bread and cooking.'},
            {'name': 'Cheese', 'brand': 'Adam\'s', 'weight': '400g', 'price': 650, 'category': 'Dairy & Eggs', 'rating': 4.6, 'stock': 40, 'description': 'Processed cheddar cheese slices.'},
            {'name': 'Eggs', 'brand': 'Generic', 'weight': '12 Pack', 'price': 360, 'old_price': 420, 'discount_percent': 14, 'category': 'Dairy & Eggs', 'rating': 4.5, 'stock': 150, 'is_bestseller': True, 'description': 'Fresh farm eggs, pack of 12.'},
            {'name': 'Cream', 'brand': 'Olper\'s', 'weight': '200ml', 'price': 220, 'category': 'Dairy & Eggs', 'rating': 4.5, 'stock': 50, 'description': 'Dairy cream for cooking and desserts.'},

            # ===== BAKERY & BREAD =====
            {'name': 'Bread', 'brand': 'National', 'weight': '800g', 'price': 220, 'category': 'Bakery & Bread', 'rating': 4.3, 'stock': 100, 'is_bestseller': True, 'description': 'Fresh white bread, soft and delicious.'},
            {'name': 'Bread', 'brand': 'National', 'weight': '400g', 'price': 140, 'category': 'Bakery & Bread', 'rating': 4.2, 'stock': 120, 'description': 'Small pack white bread.'},
            {'name': 'Whole Wheat Bread', 'brand': 'National', 'weight': '600g', 'price': 180, 'category': 'Bakery & Bread', 'rating': 4.4, 'stock': 80, 'description': 'Healthy whole wheat bread for a balanced diet.'},

            # ===== BISCUITS & COOKIES =====
            {'name': 'Biscuits', 'brand': 'Peek Freans', 'weight': '300g', 'price': 120, 'category': 'Biscuits & Cookies', 'rating': 4.4, 'stock': 150, 'is_bestseller': True, 'description': 'Classic family biscuits for tea time.'},
            {'name': 'Cookies', 'brand': 'LU', 'weight': '200g', 'price': 180, 'category': 'Biscuits & Cookies', 'rating': 4.6, 'stock': 100, 'description': 'Premium chocolate chip cookies.'},
            {'name': 'Marie Biscuits', 'brand': 'Peek Freans', 'weight': '250g', 'price': 85, 'category': 'Biscuits & Cookies', 'rating': 4.3, 'stock': 120, 'description': 'Light and crispy Marie biscuits.'},
            {'name': 'Glucose Biscuits', 'brand': 'Super', 'weight': '350g', 'price': 95, 'category': 'Biscuits & Cookies', 'rating': 4.2, 'stock': 130, 'description': 'Sweet glucose biscuits for kids.'},

            # ===== CEREALS & NOODLES =====
            {'name': 'Corn Flakes', 'brand': 'Nestle', 'weight': '500g', 'price': 650, 'old_price': 750, 'discount_percent': 13, 'category': 'Cereals & Noodles', 'rating': 4.6, 'stock': 60, 'is_featured': True, 'description': 'Crunchy corn flakes for a healthy breakfast.'},
            {'name': 'Pasta', 'brand': 'Bake Parlor', 'weight': '500g', 'price': 250, 'category': 'Cereals & Noodles', 'rating': 4.4, 'stock': 80, 'description': 'Premium quality pasta for Italian dishes.'},
            {'name': 'Noodles', 'brand': 'Knorr', 'weight': '70g', 'price': 45, 'category': 'Cereals & Noodles', 'rating': 4.5, 'stock': 200, 'is_bestseller': True, 'description': 'Instant chicken noodles for a quick meal.'},
            {'name': 'Spaghetti', 'brand': 'Bake Parlor', 'weight': '500g', 'price': 280, 'category': 'Cereals & Noodles', 'rating': 4.5, 'stock': 70, 'description': 'Long spaghetti for pasta dishes.'},
            {'name': 'Oats', 'brand': 'Quaker', 'weight': '500g', 'price': 550, 'category': 'Cereals & Noodles', 'rating': 4.7, 'stock': 50, 'description': 'Rolled oats for a nutritious breakfast.'},

            # ===== SAUCES & PICKLES =====
            {'name': 'Ketchup', 'brand': 'National', 'weight': '800g', 'price': 450, 'category': 'Sauces & Pickles', 'rating': 4.6, 'stock': 100, 'is_bestseller': True, 'description': 'Tomato ketchup for snacks and meals.'},
            {'name': 'Soy Sauce', 'brand': 'National', 'weight': '250ml', 'price': 180, 'category': 'Sauces & Pickles', 'rating': 4.5, 'stock': 80, 'description': 'Dark soy sauce for Chinese dishes.'},
            {'name': 'Chilli Garlic Sauce', 'brand': 'National', 'weight': '500g', 'price': 320, 'category': 'Sauces & Pickles', 'rating': 4.6, 'stock': 70, 'description': 'Spicy chilli garlic sauce for dosas and snacks.'},
            {'name': 'Mango Pickle', 'brand': 'National', 'weight': '900g', 'price': 380, 'category': 'Sauces & Pickles', 'rating': 4.5, 'stock': 60, 'description': 'Traditional achar for Pakistani meals.'},
            {'name': 'Vinegar', 'brand': 'National', 'weight': '800ml', 'price': 150, 'category': 'Sauces & Pickles', 'rating': 4.3, 'stock': 70, 'description': 'White synthetic vinegar for cooking.'},
            {'name': 'Mayonnaise', 'brand': 'Young\'s', 'weight': '500g', 'price': 350, 'category': 'Sauces & Pickles', 'rating': 4.6, 'stock': 60, 'description': 'Creamy mayonnaise for sandwiches and burgers.'},
            {'name': 'Jam', 'brand': 'Mitchell\'s', 'weight': '500g', 'price': 280, 'category': 'Sauces & Pickles', 'rating': 4.5, 'stock': 70, 'description': 'Mixed fruit jam for breakfast.'},
            {'name': 'Honey', 'brand': 'Marhaba', 'weight': '500g', 'price': 650, 'old_price': 750, 'discount_percent': 13, 'category': 'Sauces & Pickles', 'rating': 4.8, 'stock': 40, 'description': 'Pure natural honey for health and taste.'},

            # ===== DRY FRUITS & NUTS =====
            {'name': 'Almonds', 'brand': 'Generic', 'weight': '500g', 'price': 1200, 'category': 'Dry Fruits & Nuts', 'rating': 4.7, 'stock': 40, 'description': 'Premium quality almonds, rich in nutrients.'},
            {'name': 'Cashews', 'brand': 'Generic', 'weight': '250g', 'price': 850, 'category': 'Dry Fruits & Nuts', 'rating': 4.6, 'stock': 35, 'description': 'Whole cashew nuts for snacking and cooking.'},
            {'name': 'Raisins', 'brand': 'Generic', 'weight': '500g', 'price': 600, 'category': 'Dry Fruits & Nuts', 'rating': 4.5, 'stock': 50, 'description': 'Sweet golden raisins for desserts and snacks.'},
            {'name': 'Walnuts', 'brand': 'Generic', 'weight': '250g', 'price': 750, 'category': 'Dry Fruits & Nuts', 'rating': 4.6, 'stock': 30, 'description': 'Fresh walnuts for brain health.'},
            {'name': 'Dates', 'brand': 'Generic', 'weight': '1kg', 'price': 800, 'category': 'Dry Fruits & Nuts', 'rating': 4.7, 'stock': 60, 'description': 'Premium quality dates for energy.'},

            # ===== SNACKS & CHOCOLATES =====
            {'name': 'Chips', 'brand': 'Lays', 'weight': '70g', 'price': 80, 'category': 'Snacks & Chocolates', 'rating': 4.5, 'stock': 200, 'description': 'Classic salted potato chips.'},
            {'name': 'Chocolate', 'brand': 'Cadbury', 'weight': '120g', 'price': 250, 'category': 'Snacks & Chocolates', 'rating': 4.8, 'stock': 100, 'is_featured': True, 'description': 'Dairy milk chocolate for chocolate lovers.'},
            {'name': 'Wafers', 'brand': 'Prince', 'weight': '100g', 'price': 60, 'category': 'Snacks & Chocolates', 'rating': 4.4, 'stock': 150, 'description': 'Chocolate filled wafer biscuits.'},
            {'name': 'Namkeen', 'brand': 'Haldiram\'s', 'weight': '200g', 'price': 150, 'category': 'Snacks & Chocolates', 'rating': 4.6, 'stock': 80, 'description': 'Crunchy Indian namkeen mix.'},
            {'name': 'Popcorn', 'brand': 'Act II', 'weight': '70g', 'price': 95, 'category': 'Snacks & Chocolates', 'rating': 4.5, 'stock': 100, 'description': 'Butter-flavored instant popcorn.'},

            # ===== JUICES & DRINKS =====
            {'name': 'Juice', 'brand': 'Nestle', 'weight': '1L', 'price': 280, 'category': 'Juices & Drinks', 'rating': 4.5, 'stock': 80, 'description': 'Pack fruit juice, refreshing and tasty.'},
            {'name': 'Soft Drink', 'brand': 'Coca Cola', 'weight': '1.5L', 'price': 120, 'category': 'Juices & Drinks', 'rating': 4.4, 'stock': 200, 'is_bestseller': True, 'description': 'Classic Coca Cola for refreshment.'},
            {'name': 'Soft Drink', 'brand': 'Pepsi', 'weight': '1.5L', 'price': 120, 'category': 'Juices & Drinks', 'rating': 4.4, 'stock': 200, 'description': 'Pepsi cola for a refreshing break.'},
            {'name': 'Rooh Afza', 'brand': 'Hamdard', 'weight': '1L', 'price': 350, 'category': 'Juices & Drinks', 'rating': 4.7, 'stock': 60, 'description': 'Traditional rose sharbat for summer.'},
            {'name': 'Squash', 'brand': 'Mitchell\'s', 'weight': '750ml', 'price': 280, 'category': 'Juices & Drinks', 'rating': 4.5, 'stock': 50, 'description': 'Mango squash for homemade drinks.'},

            # ===== WATER =====
            {'name': 'Mineral Water', 'brand': 'Nestle', 'weight': '1.5L', 'price': 60, 'category': 'Water', 'rating': 4.5, 'stock': 300, 'is_bestseller': True, 'description': 'Purified mineral water for safe drinking.'},
            {'name': 'Mineral Water', 'brand': 'Aquafina', 'weight': '1.5L', 'price': 55, 'category': 'Water', 'rating': 4.4, 'stock': 250, 'description': 'Purified drinking water.'},
            {'name': 'Water Bottles', 'brand': 'Nestle', 'weight': '250ml x 12', 'price': 480, 'category': 'Water', 'rating': 4.5, 'stock': 100, 'description': 'Pack of 12 small water bottles.'},

            # ===== HOUSEHOLD - LAUNDRY =====
            {'name': 'Washing Powder', 'brand': 'Ariel', 'weight': '1kg', 'price': 420, 'old_price': 480, 'discount_percent': 13, 'category': 'Laundry', 'rating': 4.7, 'stock': 100, 'is_featured': True, 'is_bestseller': True, 'description': 'Ariel automatic washing powder for tough stains.'},
            {'name': 'Washing Powder', 'brand': 'Surf Excel', 'weight': '1kg', 'price': 380, 'category': 'Laundry', 'rating': 4.5, 'stock': 100, 'description': 'Surf Excel for brilliant clean clothes.'},
            {'name': 'Detergent Liquid', 'brand': 'Ariel', 'weight': '2L', 'price': 850, 'category': 'Laundry', 'rating': 4.6, 'stock': 60, 'description': 'Liquid detergent for gentle yet effective cleaning.'},
            {'name': 'Fabric Softener', 'brand': 'Downy', 'weight': '1L', 'price': 550, 'category': 'Laundry', 'rating': 4.7, 'stock': 50, 'description': 'Downy fabric softener for soft and fragrant clothes.'},
            {'name': 'Stain Remover', 'brand': 'Vanish', 'weight': '500g', 'price': 350, 'category': 'Laundry', 'rating': 4.5, 'stock': 40, 'description': 'Vanish stain remover for tough stains.'},

            # ===== HOUSEHOLD - DISHWASHING =====
            {'name': 'Dishwashing Liquid', 'brand': 'Morning Fresh', 'weight': '500ml', 'price': 280, 'category': 'Dishwashing', 'rating': 4.5, 'stock': 80, 'is_bestseller': True, 'description': 'Morning Fresh dishwashing liquid for clean dishes.'},
            {'name': 'Dishwashing Soap', 'brand': 'Vim', 'weight': '3 Pack', 'price': 150, 'category': 'Dishwashing', 'rating': 4.4, 'stock': 100, 'description': 'Vim dishwashing bar for tough grease.'},
            {'name': 'Dishwasher Tablet', 'brand': 'Finish', 'weight': '30 Tabs', 'price': 850, 'category': 'Dishwashing', 'rating': 4.7, 'stock': 30, 'description': 'Finish all-in-1 dishwasher tablets.'},

            # ===== HOUSEHOLD - CLEANERS =====
            {'name': 'Floor Cleaner', 'brand': 'Lizol', 'weight': '1L', 'price': 390, 'category': 'Cleaners', 'rating': 4.6, 'stock': 70, 'is_bestseller': True, 'description': 'Lizol floor cleaner for sparkling clean floors.'},
            {'name': 'Toilet Cleaner', 'brand': 'Harpic', 'weight': '500ml', 'price': 300, 'category': 'Cleaners', 'rating': 4.5, 'stock': 80, 'description': 'Harpic power plus toilet cleaner.'},
            {'name': 'Glass Cleaner', 'brand': 'Klear', 'weight': '500ml', 'price': 250, 'category': 'Cleaners', 'rating': 4.4, 'stock': 50, 'description': 'Klear glass cleaner for streak-free shine.'},
            {'name': 'Bleach', 'brand': 'Hamam', 'weight': '500ml', 'price': 180, 'category': 'Cleaners', 'rating': 4.3, 'stock': 60, 'description': 'Household bleach for disinfecting.'},
            {'name': 'Surface Cleaner', 'brand': 'Domex', 'weight': '500ml', 'price': 320, 'category': 'Cleaners', 'rating': 4.6, 'stock': 50, 'description': 'Multi-surface cleaner for kitchen and bathroom.'},

            # ===== HOUSEHOLD - TISSUES & BAGS =====
            {'name': 'Tissue Box', 'brand': 'Fine', 'weight': '150 sheets', 'price': 250, 'category': 'Tissues & Bags', 'rating': 4.5, 'stock': 100, 'is_bestseller': True, 'description': 'Soft facial tissues in premium box.'},
            {'name': 'Toilet Tissue', 'brand': 'Fine', 'weight': '6 Roll', 'price': 380, 'category': 'Tissues & Bags', 'rating': 4.4, 'stock': 80, 'description': 'Soft toilet tissue rolls.'},
            {'name': 'Kitchen Towels', 'brand': 'Fine', 'weight': '2 Roll', 'price': 300, 'category': 'Tissues & Bags', 'rating': 4.5, 'stock': 70, 'description': 'Absorbent kitchen paper towels.'},
            {'name': 'Garbage Bags', 'brand': 'Generic', 'weight': '30 bags', 'price': 200, 'category': 'Tissues & Bags', 'rating': 4.3, 'stock': 90, 'description': 'Large garbage bags for household waste.'},
            {'name': 'Aluminium Foil', 'brand': 'Generic', 'weight': '9m', 'price': 180, 'category': 'Tissues & Bags', 'rating': 4.4, 'stock': 60, 'description': 'Kitchen aluminium foil for cooking and wrapping.'},
            {'name': 'Cling Film', 'brand': 'Generic', 'weight': '30m', 'price': 150, 'category': 'Tissues & Bags', 'rating': 4.3, 'stock': 50, 'description': 'Plastic wrap for food storage.'},

            # ===== HOUSEHOLD - CLEANING TOOLS =====
            {'name': 'Sponges', 'brand': 'Generic', 'weight': '3 Pack', 'price': 120, 'category': 'Cleaning Tools', 'rating': 4.3, 'stock': 100, 'description': 'Multi-purpose cleaning sponges.'},
            {'name': 'Scrubbers', 'brand': 'Generic', 'weight': '5 Pack', 'price': 150, 'category': 'Cleaning Tools', 'rating': 4.4, 'stock': 80, 'description': 'Steel scrubbers for tough cleaning.'},
            {'name': 'Broom', 'brand': 'Generic', 'weight': '1 Pc', 'price': 250, 'category': 'Cleaning Tools', 'rating': 4.2, 'stock': 60, 'description': 'Standard household broom.'},
            {'name': 'Mop', 'brand': 'Generic', 'weight': '1 Set', 'price': 450, 'category': 'Cleaning Tools', 'rating': 4.4, 'stock': 40, 'description': 'Spin mop with bucket for easy cleaning.'},

            # ===== HOUSEHOLD - BUCKETS & DUSTBINS =====
            {'name': 'Buckets', 'brand': 'Generic', 'weight': '1 Pc', 'price': 350, 'category': 'Buckets & Dustbins', 'rating': 4.2, 'stock': 50, 'description': 'Durable plastic bucket for household use.'},
            {'name': 'Dustbin', 'brand': 'Generic', 'weight': '1 Pc', 'price': 550, 'category': 'Buckets & Dustbins', 'rating': 4.3, 'stock': 30, 'description': 'Pedal dustbin with lid for kitchen.'},

            # ===== AIR FRESHENERS =====
            {'name': 'Air Freshener', 'brand': 'Odonil', 'weight': '1 Pc', 'price': 180, 'category': 'Air Fresheners', 'rating': 4.4, 'stock': 80, 'description': 'Air freshener for long-lasting fragrance.'},
            {'name': 'Room Spray', 'brand': 'Glade', 'weight': '300ml', 'price': 350, 'category': 'Air Fresheners', 'rating': 4.5, 'stock': 50, 'description': 'Automatic room spray for fresh air.'},

            # ===== INSECT KILLERS =====
            {'name': 'Insect Killer Spray', 'brand': 'Mortein', 'weight': '600ml', 'price': 320, 'category': 'Insect Killers', 'rating': 4.5, 'stock': 60, 'description': 'Mortein power spray for mosquitoes.'},
            {'name': 'Mosquito Repellent', 'brand': 'Self', 'weight': '30ml', 'price': 150, 'category': 'Insect Killers', 'rating': 4.4, 'stock': 80, 'description': 'Mosquito repellent liquid for vaporizer.'},

            # ===== PERSONAL CARE - HAIR CARE =====
            {'name': 'Shampoo', 'brand': 'Pantene', 'weight': '400ml', 'price': 750, 'old_price': 850, 'discount_percent': 12, 'category': 'Hair Care', 'rating': 4.7, 'stock': 60, 'is_featured': True, 'is_bestseller': True, 'description': 'Pantene shampoo for strong and shiny hair.'},
            {'name': 'Shampoo', 'brand': 'Head & Shoulders', 'weight': '400ml', 'price': 720, 'category': 'Hair Care', 'rating': 4.6, 'stock': 60, 'description': 'Anti-dandruff shampoo for clean scalp.'},
            {'name': 'Conditioner', 'brand': 'Pantene', 'weight': '400ml', 'price': 800, 'category': 'Hair Care', 'rating': 4.6, 'stock': 40, 'description': 'Pantene conditioner for silky smooth hair.'},
            {'name': 'Hair Oil', 'brand': 'Sunsilk', 'weight': '200ml', 'price': 350, 'category': 'Hair Care', 'rating': 4.4, 'stock': 50, 'description': 'Black shine hair oil for glossy hair.'},

            # ===== PERSONAL CARE - BATH & BODY =====
            {'name': 'Bath Soap', 'brand': 'Dettol', 'weight': '3 Pack', 'price': 450, 'category': 'Bath & Body', 'rating': 4.6, 'stock': 80, 'is_bestseller': True, 'description': 'Dettol original soap for protection and cleanliness.'},
            {'name': 'Bath Soap', 'brand': 'Lifebuoy', 'weight': '3 Pack', 'price': 350, 'category': 'Bath & Body', 'rating': 4.4, 'stock': 90, 'description': 'Lifebuoy total 10 soap for germ protection.'},
            {'name': 'Hand Wash', 'brand': 'Dettol', 'weight': '500ml', 'price': 400, 'category': 'Bath & Body', 'rating': 4.7, 'stock': 70, 'is_bestseller': True, 'description': 'Dettol hand wash for healthy hands.'},
            {'name': 'Body Wash', 'brand': 'Dove', 'weight': '500ml', 'price': 550, 'category': 'Bath & Body', 'rating': 4.6, 'stock': 40, 'description': 'Dove nourishing body wash.'},
            {'name': 'Face Wash', 'brand': 'Garnier', 'weight': '100ml', 'price': 350, 'category': 'Bath & Body', 'rating': 4.5, 'stock': 50, 'description': 'Garnier men face wash for oil control.'},

            # ===== PERSONAL CARE - ORAL CARE =====
            {'name': 'Toothpaste', 'brand': 'Colgate', 'weight': '150g', 'price': 350, 'category': 'Oral Care', 'rating': 4.7, 'stock': 100, 'is_bestseller': True, 'description': 'Colgate max fresh toothpaste for strong teeth.'},
            {'name': 'Toothpaste', 'brand': 'Sensodyne', 'weight': '100g', 'price': 450, 'category': 'Oral Care', 'rating': 4.8, 'stock': 50, 'description': 'Sensodyne for sensitive teeth.'},
            {'name': 'Toothbrush', 'brand': 'Oral-B', 'weight': '1 Pc', 'price': 180, 'category': 'Oral Care', 'rating': 4.5, 'stock': 80, 'description': 'Oral-B toothbrush for deep cleaning.'},
            {'name': 'Mouthwash', 'brand': 'Listerine', 'weight': '250ml', 'price': 380, 'category': 'Oral Care', 'rating': 4.6, 'stock': 40, 'description': 'Listerine cool mint mouthwash.'},

            # ===== PERSONAL CARE - DEODORANTS =====
            {'name': 'Deodorant', 'brand': 'Rexona', 'weight': '150ml', 'price': 450, 'category': 'Deodorants', 'rating': 4.5, 'stock': 60, 'description': 'Rexona motion sense deodorant.'},
            {'name': 'Deodorant', 'brand': 'Nivea', 'weight': '150ml', 'price': 480, 'category': 'Deodorants', 'rating': 4.6, 'stock': 50, 'description': 'Nivea men deodorant for long freshness.'},

            # ===== PERSONAL CARE - SHAVING =====
            {'name': 'Shaving Cream', 'brand': 'Gillette', 'weight': '100g', 'price': 350, 'category': 'Shaving', 'rating': 4.5, 'stock': 40, 'description': 'Gillette series shaving cream.'},
            {'name': 'Razor Blades', 'brand': 'Gillette', 'weight': '8 Pack', 'price': 650, 'category': 'Shaving', 'rating': 4.6, 'stock': 30, 'description': 'Gillette mach3 razor blade refills.'},

            # ===== PERSONAL CARE - SKINCARE =====
            {'name': 'Moisturizer', 'brand': 'Nivea', 'weight': '200ml', 'price': 550, 'category': 'Skincare', 'rating': 4.7, 'stock': 40, 'description': 'Nivea soft moisturizing cream.'},
            {'name': 'Sunscreen', 'brand': 'Nivea', 'weight': '100ml', 'price': 650, 'category': 'Skincare', 'rating': 4.6, 'stock': 30, 'description': 'Nivea sun protect sunscreen.'},
            {'name': 'Petroleum Jelly', 'brand': 'Vaseline', 'weight': '200ml', 'price': 350, 'category': 'Skincare', 'rating': 4.5, 'stock': 50, 'description': 'Vaseline original petroleum jelly.'},

            # ===== PERSONAL CARE - BABY CARE =====
            {'name': 'Baby Diapers', 'brand': 'Pampers', 'weight': 'S-3 Pack', 'price': 850, 'category': 'Baby Care', 'rating': 4.7, 'stock': 40, 'description': 'Pampers premium care diapers.'},
            {'name': 'Baby Soap', 'brand': 'Johnson\'s', 'weight': '3 Pack', 'price': 450, 'category': 'Baby Care', 'rating': 4.8, 'stock': 50, 'description': 'Johnson\'s baby soap for gentle care.'},
            {'name': 'Baby Shampoo', 'brand': 'Johnson\'s', 'weight': '300ml', 'price': 550, 'category': 'Baby Care', 'rating': 4.7, 'stock': 40, 'description': 'Johnson\'s baby shampoo no more tears.'},
            {'name': 'Baby Powder', 'brand': 'Johnson\'s', 'weight': '500g', 'price': 400, 'category': 'Baby Care', 'rating': 4.6, 'stock': 50, 'description': 'Johnson\'s baby powder for soft skin.'},

            # ===== HOME & KITCHEN - DINNERWARE =====
            {'name': 'Dinner Set', 'brand': 'IKEA', 'weight': '24 Pieces', 'price': 3500, 'category': 'Dinnerware', 'rating': 4.7, 'stock': 15, 'description': 'Complete ceramic dinner set for family.'},
            {'name': 'Plates', 'brand': 'IKEA', 'weight': '4 Pack', 'price': 800, 'category': 'Dinnerware', 'rating': 4.5, 'stock': 25, 'description': 'Dinner plates set of 4.'},
            {'name': 'Bowls', 'brand': 'IKEA', 'weight': '4 Pack', 'price': 600, 'category': 'Dinnerware', 'rating': 4.4, 'stock': 30, 'description': 'Serving bowls set of 4.'},

            # ===== HOME & KITCHEN - DRINKWARE =====
            {'name': 'Glasses', 'brand': 'IKEA', 'weight': '6 Pack', 'price': 750, 'category': 'Drinkware', 'rating': 4.5, 'stock': 20, 'description': 'Drinking glasses set of 6.'},
            {'name': 'Cups', 'brand': 'IKEA', 'weight': '6 Pack', 'price': 650, 'category': 'Drinkware', 'rating': 4.4, 'stock': 25, 'description': 'Tea cups set of 6.'},
            {'name': 'Mugs', 'brand': 'IKEA', 'weight': '4 Pack', 'price': 550, 'category': 'Drinkware', 'rating': 4.5, 'stock': 30, 'description': 'Coffee mugs set of 4.'},

            # ===== HOME & KITCHEN - CUTLERY =====
            {'name': 'Cutlery Set', 'brand': 'IKEA', 'weight': '24 Pieces', 'price': 1200, 'category': 'Cutlery', 'rating': 4.6, 'stock': 15, 'description': 'Stainless steel cutlery set.'},
            {'name': 'Knife Set', 'brand': 'IKEA', 'weight': '5 Pieces', 'price': 1500, 'category': 'Cutlery', 'rating': 4.7, 'stock': 10, 'description': 'Professional kitchen knife set.'},

            # ===== HOME & KITCHEN - COOKING UTENSILS =====
            {'name': 'Cookware Set', 'brand': 'IKEA', 'weight': '5 Pieces', 'price': 4500, 'category': 'Cooking Utensils', 'rating': 4.8, 'stock': 10, 'is_featured': True, 'description': 'Non-stick cookware set for modern kitchen.'},
            {'name': 'Frying Pan', 'brand': 'IKEA', 'weight': '1 Pc', 'price': 1200, 'category': 'Cooking Utensils', 'rating': 4.6, 'stock': 20, 'description': 'Non-stick frying pan.'},
            {'name': 'Pressure Cooker', 'brand': 'Prestige', 'weight': '5L', 'price': 3500, 'category': 'Cooking Utensils', 'rating': 4.7, 'stock': 10, 'description': 'Prestige pressure cooker for quick cooking.'},

            # ===== HOME & KITCHEN - STORAGE =====
            {'name': 'Storage Containers', 'brand': 'IKEA', 'weight': '10 Pieces', 'price': 800, 'category': 'Storage', 'rating': 4.5, 'stock': 25, 'description': 'Airtight food storage containers.'},
            {'name': 'Lunch Box', 'brand': 'Generic', 'weight': '3 Compartments', 'price': 450, 'category': 'Storage', 'rating': 4.4, 'stock': 30, 'description': 'Steel lunch box with compartments.'},

            # ===== HOME & KITCHEN - BOTTLES =====
            {'name': 'Water Bottle', 'brand': 'IKEA', 'weight': '1L', 'price': 350, 'category': 'Bottles', 'rating': 4.5, 'stock': 40, 'description': 'Reusable water bottle.'},
            {'name': 'Flask', 'brand': 'Generic', 'weight': '1L', 'price': 800, 'category': 'Bottles', 'rating': 4.6, 'stock': 20, 'description': 'Insulated steel flask for hot and cold drinks.'},

            # ===== HOME & KITCHEN - ACCESSORIES =====
            {'name': 'Chopping Board', 'brand': 'IKEA', 'weight': '1 Pc', 'price': 500, 'category': 'Kitchen Accessories', 'rating': 4.4, 'stock': 25, 'description': 'Plastic chopping board for food prep.'},
            {'name': 'Rolling Pin', 'brand': 'Generic', 'weight': '1 Pc', 'price': 300, 'category': 'Kitchen Accessories', 'rating': 4.3, 'stock': 20, 'description': 'Wooden belan for roti making.'},
            {'name': 'Sieve', 'brand': 'Generic', 'weight': '1 Pc', 'price': 200, 'category': 'Kitchen Accessories', 'rating': 4.2, 'stock': 25, 'description': 'Flour sieve for baking.'},
            {'name': 'Kitchen Timer', 'brand': 'Generic', 'weight': '1 Pc', 'price': 250, 'category': 'Kitchen Accessories', 'rating': 4.4, 'stock': 15, 'description': 'Digital kitchen timer for cooking.'},
        ]

        created_count = 0
        for p in products:
            category = Category.objects.filter(name=p['category']).first()
            if not category:
                continue
            product, created = Product.objects.get_or_create(
                name=p['name'],
                category=category,
                defaults={
                    'slug': slugify(f"{p['name']}-{p['brand']}-{p['weight']}"),
                    'description': p['description'],
                    'brand': p['brand'],
                    'weight': p['weight'],
                    'price': p['price'],
                    'old_price': p.get('old_price'),
                    'discount_percent': p.get('discount_percent', 0),
                    'rating': p['rating'],
                    'stock': p['stock'],
                    'is_featured': p.get('is_featured', False),
                    'is_bestseller': p.get('is_bestseller', False),
                    'is_new_arrival': p.get('is_new_arrival', False),
                }
            )
            if created:
                created_count += 1

        self.stdout.write(f'  Created {created_count} products')
